# V8 build strategy

V8 fixes a configuration-order bug found from the real GitHub Actions log.
ESP-IDF loads `sdkconfig.defaults` first and `sdkconfig.defaults.esp32s3` after it.
Therefore a camera/DVP choice placed only in the generic defaults can be
silently overridden by the later target-specific defaults.

V8 now:

1. preserves the vendor generic defaults;
2. writes the final MAX35/GC0308/DVP choices to `sdkconfig.defaults.esp32s3`;
3. removes conflicting board/OV5640 choices from the final layer;
4. injects a board-level Kconfig `select` for the DVP video device as a second
   safety net when the MAX35 board itself is selected;
5. verifies the generated `sdkconfig` before the C++ build starts.

The UI architecture is unchanged: `ui_home.cc`, `ui_chat.cc`, and
`ui_camera.cc` remain independently replaceable.
