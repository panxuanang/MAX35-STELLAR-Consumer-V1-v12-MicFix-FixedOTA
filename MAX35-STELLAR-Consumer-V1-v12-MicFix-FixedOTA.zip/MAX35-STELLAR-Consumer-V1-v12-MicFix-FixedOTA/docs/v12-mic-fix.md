# V12 麦克风修复说明

这一版以用户已经验证“能开机、能连 Wi-Fi、能连接自己的后台、TTS/扬声器有声音”的 V11 后摄 Wi-Fi 工程为唯一基准，不重做板级适配。

## 修改范围

- `AUDIO_INPUT_REFERENCE`：`true -> false`
- ES7210：单麦模式只启用 `MIC1`
- 输入增益：24 dB -> 30 dB
- `CONFIG_USE_DEVICE_AEC=n`
- `CONFIG_USE_SERVER_AEC=n`
- 串口：每秒输出一次 `MAX35 MIC RMS` 和 `peak`
- OTA/后台发现地址固定：`http://124.221.112.55:8002/xiaozhi/ota/`
- `Ota::GetCheckVersionUrl()` 直接返回编译时 URL，不再读取旧 NVS `wifi/ota_url`

## 为什么先用单麦

当前症状是“设备能播放，但听不到用户说话”，而旧日志显示 AFE 走 `1 microphone + 1 playback` 的参考/AEC 路径。先把输入收敛成单一的 MIC1，可以绕过尚未验证的参考通道映射，让我们先确认真实 PCM 能否稳定进入语音前端。这个改动不碰 Wi-Fi、显示、扬声器、GC0308、触摸和上层对话 UI。

## 刷机后的关键串口日志

```text
MAX35 MIC RMS=1234 peak=4567 gain=30.0 ref=0
```

数值不要求固定。关键是：保持安静时较低；正常说话/拍手时应明显升高。

- **会明显升高且能识别语音**：修复完成。
- **会明显升高但仍不识别**：继续查 VAD/ASR/协议，不再怀疑麦克风采样。
- **始终接近 0**：继续查 ES7210 MIC1、排线/焊接/模拟输入，不再盲改 UI 或网络。
