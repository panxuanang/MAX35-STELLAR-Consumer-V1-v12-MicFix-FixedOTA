# V10 root-cause fix

The V9 diagnostic proved that `sdkconfig.defaults.esp32s3` contained:

- `CONFIG_ESP_VIDEO_ENABLE_DVP_VIDEO_DEVICE=y`
- `CONFIG_CAMERA_GC0308=y`
- `CONFIG_CAMERA_GC0308_DVP_YUV422_640X480_16FPS=y`

but generated `sdkconfig` dropped the DVP option.

The vendor `esp_video` Kconfig makes DVP depend on `SOC_LCDCAM_CAM_SUPPORTED`.
The original ESP-IDF `v5.5` tag does not define that SoC capability for ESP32-S3, while
ESP-IDF `v5.5.5` does. Therefore the option was hidden by Kconfig even though defaults requested it.

V10 pins CI to ESP-IDF v5.5.5 and explicitly checks the SoC capability before configuration.
No vendor Kconfig source is patched.
