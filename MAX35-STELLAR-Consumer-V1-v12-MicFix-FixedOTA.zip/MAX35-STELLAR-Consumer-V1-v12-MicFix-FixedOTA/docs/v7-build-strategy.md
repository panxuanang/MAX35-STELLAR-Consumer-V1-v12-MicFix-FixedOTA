# V7 build strategy

V7 follows SpotPear's official MAX35 compilation flow rather than assuming the
newer 78/xiaozhi `scripts/build.py` helper exists.

CI equivalent of the vendor tutorial:

1. `idf.py set-target esp32s3`
2. Generate the saved menuconfig choices into `sdkconfig.defaults`:
   - SpotPear ESP32-S3 3.5 LCD cam board
   - non-4G rear camera SKU
   - GC0308
   - DVP video device
   - YUV422 when the installed esp-video-components exposes that symbol
   - WeChat message style disabled
   - all existing vendor defaults and selected config.json append options retained
3. `idf.py reconfigure`
4. Verify the generated `sdkconfig`
5. `idf.py build`

The product overlay still owns only UI / Todo / camera-touch-confirmation logic.
The SpotPear board owns LCD, touch, audio, camera pins and power hardware.
