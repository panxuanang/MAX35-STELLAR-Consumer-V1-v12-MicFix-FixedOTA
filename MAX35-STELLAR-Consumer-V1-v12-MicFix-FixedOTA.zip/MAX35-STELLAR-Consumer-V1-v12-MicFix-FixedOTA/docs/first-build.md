# 第一次 GitHub Actions 编译

## 1. 上传仓库

请确认这些路径都上传了：

```text
.github/workflows/build-max35.yml
overlay/main/display/stellar_max35/
scripts/
VERSION
```

GitHub 网页上传时不要遗漏 `.github`，否则不会出现 Workflow。

## 2. 运行 Workflow

进入：

`Actions -> Build MAX35 STELLAR Consumer MicFix -> Run workflow`

Workflow 使用 `espressif/idf:v5.5.5`，与 SpotPear 当前 MAX35 教程所要求的 ESP-IDF 5.5 对齐。

默认从 SpotPear 教程所指向的 Google Drive 文件下载 `xiaozhi-esp32-3.1.0`。

## 3. 如果 Google Drive 下载受限

在仓库：

`Settings -> Secrets and variables -> Actions -> Secrets`

新增：

```text
XIAOZHI_SOURCE_URL
```

值填写你自己可直接下载的 SpotPear `xiaozhi-esp32-3.1.0.zip` 地址。Workflow 会优先使用这个地址。

不要把需要登录的私人下载 token 直接写进 YAML。

## 4. 板型策略

本版不再让 CI 猜板型。`configure_max35.py` 固定选择你这个已验证 Wi-Fi 工程使用的：

```text
CONFIG_BOARD_TYPE_SPOTPEAR_ESP32_S3_3_5_LCD=y
main/boards/sp-esp32-s3-lcd-3.5
```

如果厂家下载包里不存在这个真实目录，Workflow 会直接失败，不会退回到 `common` 或其他“最像”的板型。

## 5. 成功后拿哪个 BIN

Artifact 中：

```text
MAX35_STELLAR_<version>_merged.bin
```

是合并后的完整烧录镜像。`components/` 目录保留 ESP-IDF 生成的分区镜像，适合调试和恢复。

## 6. 第一次实机重点验证

这一版先看“耳朵”是否恢复。串口应出现单麦路径，并在音频输入开启时约每秒出现一次：

```text
MAX35 MIC RMS=... peak=... gain=30.0 ref=0
```

你保持安静时 RMS/peak 应有较低但通常非零的底噪；对着机器正常说话时，这两个数应明显升高。然后再按下面顺序测：

1. 开机 / 配网 / 激活是否仍正常；
2. 对着设备说话，确认 `MAX35 MIC RMS` / `peak` 随声音明显变化；
3. 确认语音识别能够收到你的话；
4. 扬声器 / TTS 是否仍正常；
5. 横屏方向、触摸坐标是否一致；
6. 唤醒后是否自动进入 Chat；
7. 长回答滚动与自动回桌面；
8. GC0308 拍照流程是否仍正常。

如果说话时 `RMS/peak` 明显变化，但后台仍没有文字，问题已从“麦克风硬件/I2S”缩小到上层 VAD/ASR；如果一直接近 0，再查 ES7210/MIC1 的物理输入链路。

## 7. 当前 V12 的验证边界

本版补丁已经在本次资料中可读取的 **SpotPear 实际 `xiaozhi-esp32` 源码树**上跑过：MAX35 板型选择、UI 注入、`AUDIO_INPUT_REFERENCE=false`、ES7210 MIC1、固定 OTA 和 preflight 均通过。

当前环境没有完整 ESP-IDF 5.5.5 编译工具链，所以最终 C/C++ 编译、链接和 merged BIN 生成仍由 GitHub Actions 完成。Workflow 在进入真正 build 前会再验证生成后的 `sdkconfig`，如果 AEC 或 OTA 配置被 Kconfig 改回去会直接停止。
