# V9 build strategy

V9 stops modifying vendor Kconfig files.

The product overlay only:

1. selects the exact SpotPear MAX35 board in final target defaults;
2. preserves the vendor board/config.json settings;
3. enables DVP/GC0308 options only when those symbols exist in the downloaded component tree;
4. writes final overrides to `sdkconfig.defaults.esp32s3`;
5. runs the official `idf.py set-target esp32s3` / `idf.py reconfigure` / `idf.py build` flow;
6. verifies the generated `sdkconfig` before compilation.

`main/Kconfig.projbuild` is read-only. This removes the V8 failure where a product script accidentally concatenated the next `config` token onto a `depends on` line.
