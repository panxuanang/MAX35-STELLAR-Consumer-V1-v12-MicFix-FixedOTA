# V12 – MAX35 麦克风输入修复 + 固定 OTA

- 直接基于 V11 后摄 Wi-Fi STELLAR 工程，不更换底座。
- 保留现有 Wi-Fi、UI、TTS/扬声器、GC0308、触摸和产品交互逻辑。
- `AUDIO_INPUT_REFERENCE=false`：AFE 先只接一条真实麦克风通道。
- ES7210 只启用 `MIC1`，输入增益设为 30 dB。
- 强制关闭 device-side AEC 和 server-side AEC，避免错误参考通道吞掉人声。
- `BoxAudioCodec::Read()` 每秒打印一次 `MAX35 MIC RMS=... peak=...`，便于直接从串口判断是否收到真实 PCM。
- 固定 OTA/后台发现地址为 `http://124.221.112.55:8002/xiaozhi/ota/`，并让 `Ota::GetCheckVersionUrl()` 忽略旧 NVS 的 `wifi/ota_url`。
- GitHub Actions 改成只手动运行，避免上传后自动跑一次、再手动跑一次造成重复编译。
- CI 在构建前和 `idf.py reconfigure` 后都会检查 MIC/AEC/OTA 配置，配置不对直接停止。

# V11 – GC0308 runtime fix

- Based directly on the successfully compiling V10 project.
- No UI, dialog, Todo, touch, audio or product-flow redesign.
- Locks the rear-camera SKU to GC0308 only.
- Explicitly disables every OV2640/OV5640 Kconfig symbol found in the vendor tree.
- Keeps DVP and GC0308 YUV422 configuration enabled.
- CI refuses to build if the final sdkconfig still enables OV2640 or OV5640.

# V10

- Pin CI to `espressif/idf:v5.5.5`.
- Add an explicit preflight check for ESP32-S3 `SOC_LCDCAM_CAM_SUPPORTED`.
- Keep SpotPear vendor Kconfig untouched.
- Keep V9 MAX35/GC0308/DVP final-default strategy and product UI overlay.
- Root cause fixed: the initial `v5.5` Docker tag lacks the SoC capability required by the vendor esp-video DVP Kconfig, so Kconfig silently discarded `CONFIG_ESP_VIDEO_ENABLE_DVP_VIDEO_DEVICE=y`.

# V9

- Stop patching SpotPear `main/Kconfig.projbuild`; vendor Kconfig is now read-only.
- Keep final MAX35/DVP/GC0308 overrides in `sdkconfig.defaults.esp32s3`.
- Verify generated sdkconfig before build.
- Add failure diagnostics that print the real MAX35 Kconfig block without changing it.
- Fix the V8 Kconfig syntax corruption (`depends on ... config BOARD_TYPE_OTTO_ROBOT`).

# V6 - vendor preset build strategy

- Stop deleting/regenerating SpotPear hardware sdkconfig.
- Select the MAX35 board's own config.json and preserve its sdkconfig_append entries.
- Build through the vendor Xiaozhi `scripts/build.py` path.
- Keep GC0308/DVP/audio/touch parameters vendor-owned.
- Add only a narrow DVP video-device guard when the board source uses esp_video DVP init types.
- Keep the three replaceable visual pages unchanged: `ui_home.cc`, `ui_chat.cc`, `ui_camera.cc`.

# Changelog

## 1.0.0-consumer-preview

- MAX35 product overlay architecture.
- Three independently replaceable UI pages: Home / Chat / Camera.
- Voice-driven Home -> Chat interaction inspired by the proven STELLAR flow.
- Near-full-screen readable answer surface with delayed one-way long-text scroll.
- Rear-camera homework flow gated by a local touchscreen shutter before native Capture/Explain.
- NVS memo MCP tools with RAM cache to avoid repeated flash reads during UI refresh.
- Weather injection tool; firmware does not invent local weather.
- GitHub Actions build against SpotPear's documented Xiaozhi 3.1.0 / ESP-IDF 5.5 flow.
- Merged BIN packaging plus component images and SHA-256 checksums.

## V4 build integration fix
- Resolve SpotPear MAX35 board from the exact CMake branch without assuming Waveshare-style `BOARD_DIR`.
- Supports direct `boards/...` source lists, board variables, board metadata, and a vendor-only hardware fallback.
- Prints the real MAX35 CMake branch and board files in Actions logs for deterministic diagnostics.

## V7
- Build flow now follows SpotPear official `idf.py set-target -> menuconfig -> idf.py build`.
- Removed dependency on non-existent vendor `scripts/build.py`.
- Vendor config.json and sdkconfig.defaults are merged into a deterministic non-interactive MAX35 preset.
- Added generated sdkconfig verification for board and DVP camera requirements.

## V8
- Fixed ESP-IDF defaults ordering: final MAX35/DVP settings now live in `sdkconfig.defaults.esp32s3`.
- Added MAX35 Kconfig DVP `select` safety net.
- Added final-defaults diagnostics before C++ build.
- Kept product UI and vendor hardware board separation unchanged.
