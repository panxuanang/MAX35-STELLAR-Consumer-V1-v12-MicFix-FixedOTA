#!/usr/bin/env python3
from pathlib import Path
import sys

if len(sys.argv) != 2:
    raise SystemExit("usage: preflight.py <xiaozhi-source-root>")

root = Path(sys.argv[1]).resolve()
main = root / "main"
target = (root / ".stellar_max35_target").read_text().strip()
final_defaults = root / f"sdkconfig.defaults.{target}"

required = [
    main / "display/stellar_max35/stellar_max35_display.cc",
    main / "display/stellar_max35/ui_home.cc",
    main / "display/stellar_max35/ui_chat.cc",
    main / "display/stellar_max35/ui_camera.cc",
    main / "display/stellar_max35/camera_gate.cc",
    main / "display/stellar_max35/product_tools.cc",
    main / "mcp_server.cc",
    main / "audio/codecs/box_audio_codec.cc",
    main / "ota.cc",
    root / "sdkconfig.defaults",
    final_defaults,
    root / ".stellar_max35_board_type",
    root / ".stellar_max35_target",
]
for p in required:
    if not p.exists():
        raise SystemExit(f"missing required file: {p}")
    print("[OK]", p)

board_type = (root / ".stellar_max35_board_type").read_text().strip()
board_dir = main / "boards" / board_type
if not board_dir.is_dir():
    raise SystemExit(f"selected vendor board directory missing: {board_dir}")

cfg = final_defaults.read_text(encoding="utf-8", errors="ignore")
if "CONFIG_BOARD_TYPE_SPOTPEAR_ESP32_S3_3_5_LCD=y" not in cfg:
    raise SystemExit(f"MAX35 board choice is not present in {final_defaults.name}")
print("[OK] exact MAX35 board choice is in final target defaults")

blob = "\n".join(
    p.read_text(encoding="utf-8", errors="ignore")
    for p in board_dir.rglob("*")
    if p.is_file() and p.suffix.lower() in {".c", ".cc", ".cpp", ".h", ".hpp"}
)
if "esp_video_init_dvp_config_t" in blob:
    if "CONFIG_ESP_VIDEO_ENABLE_DVP_VIDEO_DEVICE=y" not in cfg:
        raise SystemExit("vendor DVP board requires CONFIG_ESP_VIDEO_ENABLE_DVP_VIDEO_DEVICE=y in final target defaults")
    print("[OK] DVP video device enabled in final target defaults")

# V9 intentionally never edits vendor Kconfig. DVP is enforced in the final
# target-specific defaults and verified again after IDF generates sdkconfig.
print("[OK] vendor Kconfig remains unmodified by product overlay")

if "GC0308" in cfg.upper() or "gc0308" in blob.lower():
    print("[OK] GC0308 configuration/identity retained")
else:
    print("[WARN] no explicit GC0308 symbol before Kconfig generation")

# Microphone fix must be present in the selected, already-working Wi-Fi board.
board_config = board_dir / "config.h"
board_cfg_text = board_config.read_text(encoding="utf-8", errors="ignore") if board_config.exists() else ""
if not __import__("re").search(r"(?m)^\s*#define\s+AUDIO_INPUT_REFERENCE\s+false\b", board_cfg_text):
    raise SystemExit("MAX35 mic fix missing: AUDIO_INPUT_REFERENCE is not false")
print("[OK] MAX35 uses one microphone channel, playback reference disabled")

codec_text = (main / "audio/codecs/box_audio_codec.cc").read_text(encoding="utf-8", errors="ignore")
for marker in ("STELLAR MAX35 MIC FIX", "MAX35 MIC RMS=", "ES7210_SEL_MIC1"):
    if marker not in codec_text:
        raise SystemExit(f"MAX35 codec patch missing marker: {marker}")
print("[OK] BoxAudioCodec single-mic + RMS diagnostics patch present")

if "# CONFIG_USE_DEVICE_AEC is not set" not in cfg:
    raise SystemExit("final target defaults must disable CONFIG_USE_DEVICE_AEC")
print("[OK] device-side AEC disabled in final target defaults")

fixed_ota = 'CONFIG_OTA_URL="http://124.221.112.55:8002/xiaozhi/ota/"'
if fixed_ota not in cfg:
    raise SystemExit("fixed OTA/backend URL missing from final target defaults")
ota_text = (main / "ota.cc").read_text(encoding="utf-8", errors="ignore")
if "STELLAR MAX35 FIXED OTA" not in ota_text or "return CONFIG_OTA_URL;" not in ota_text:
    raise SystemExit("runtime OTA NVS override has not been disabled")
print("[OK] fixed OTA/backend URL present and runtime NVS override disabled")

cmake = (main / "CMakeLists.txt").read_text(encoding="utf-8", errors="ignore")
for name in [
    "stellar_max35_display.cc", "ui_home.cc", "ui_chat.cc", "ui_camera.cc",
    "ui_character.c", "camera_gate.cc", "stellar_todo.cc", "product_tools.cc",
]:
    if name not in cmake:
        raise SystemExit(f"CMake missing product source: {name}")
print("[OK] all product UI sources are compiled")

board_hits = []
for p in board_dir.rglob("*"):
    if p.is_file() and p.suffix.lower() in {".h", ".hpp", ".cc", ".cpp"}:
        if "StellarMax35Display" in p.read_text(encoding="utf-8", errors="ignore"):
            board_hits.append(p)
if not board_hits:
    raise SystemExit("selected MAX35 board was not attached to StellarMax35Display")
print("[OK] product display attached to vendor board")

mcp = (main / "mcp_server.cc").read_text(encoding="utf-8", errors="ignore")
if "stellar_max35::WaitForCameraConsent" not in mcp:
    raise SystemExit("camera shutter gate missing")
print("[OK] camera shutter gate present")
print("[done] source preflight passed")
