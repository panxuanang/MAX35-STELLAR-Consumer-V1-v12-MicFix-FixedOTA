#!/usr/bin/env python3
from pathlib import Path
import json
import os
import re
import shutil
import sys

if len(sys.argv) != 2:
    raise SystemExit("usage: apply_mods.py <xiaozhi-source-root>")

repo = Path(__file__).resolve().parents[1]
root = Path(sys.argv[1]).resolve()
main = root / "main"
boards_root = main / "boards"
cmake_path = main / "CMakeLists.txt"

if not cmake_path.exists():
    raise SystemExit(f"invalid Xiaozhi source root: {root}")
if not boards_root.is_dir():
    raise SystemExit(f"missing boards directory: {boards_root}")

BOARD_CONFIG = "CONFIG_BOARD_TYPE_SPOTPEAR_ESP32_S3_3_5_LCD"
SOURCE_SUFFIXES = {".c", ".cc", ".cpp", ".h", ".hpp"}


def function_close(text: str, signature_pos: int) -> int:
    brace = text.find("{", signature_pos)
    if brace < 0:
        raise SystemExit("function opening brace not found")
    depth = 0
    for i in range(brace, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return i
    raise SystemExit("function closing brace not found")


def extract_exact_board_block(cmake_text: str) -> str:
    start = re.search(
        rf"(?m)^\s*(?:if|elseif)\(\s*{re.escape(BOARD_CONFIG)}\s*\)\s*$",
        cmake_text,
    )
    if not start:
        raise SystemExit(f"Exact MAX35 CMake block not found: {BOARD_CONFIG}")

    rest = cmake_text[start.end():]
    next_branch = re.search(
        r"(?m)^\s*(?:elseif\(|else\s*(?:\(\s*\))?\s*$|endif\(\s*\))",
        rest,
    )
    end = start.end() + (next_branch.start() if next_branch else len(rest))
    block = cmake_text[start.start():end]
    print("[cmake] exact MAX35 block follows:")
    print("---------------- MAX35 CMake block ----------------")
    print(block.rstrip())
    print("-----------------------------------------------------")
    return block


def is_under(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def candidate_from_path(path: Path) -> Path | None:
    """Return the nearest board directory for a board source path."""
    p = path.resolve()
    if not is_under(p, boards_root):
        return None
    cur = p if p.is_dir() else p.parent
    # Do not ever select shared common as the product board.
    while cur != boards_root:
        if cur.name.lower() == "common":
            return None
        # Prefer directories that actually contain source/header files or config.json.
        if (cur / "config.json").exists() or any(
            q.is_file() and q.suffix.lower() in SOURCE_SUFFIXES for q in cur.iterdir()
        ):
            return cur
        cur = cur.parent
    return None


def dirs_from_cmake_block(block: str) -> list[Path]:
    found: list[Path] = []

    # Layout A (newer upstream): set(BOARD_DIR "vendor/board")
    for rel in re.findall(r'set\(\s*BOARD_DIR\s+"([^"\n]+)"\s*\)', block, flags=re.I):
        d = boards_root / rel
        if d.is_dir():
            found.append(d.resolve())
            print("[board] CMake BOARD_DIR ->", d)

    # Layout B (older/vendor forks): the exact branch appends board source files directly.
    # Match both quoted and unquoted boards/... paths.
    path_strings = set(re.findall(r'"([^"\n]*boards/[^"\n]+)"', block))
    path_strings.update(
        re.findall(r'(?<![A-Za-z0-9_])((?:\$\{CMAKE_CURRENT_SOURCE_DIR\}/)?boards/[A-Za-z0-9_./${}-]+)', block)
    )
    for raw in sorted(path_strings):
        if "${" in raw:
            continue
        raw = raw.replace("${CMAKE_CURRENT_SOURCE_DIR}/", "")
        p = main / raw
        if p.exists():
            d = candidate_from_path(p)
            if d:
                found.append(d.resolve())
                print("[board] CMake source path ->", p, "=>", d)

    # Layout C: branch sets a variable such as BOARD_TYPE/BOARD_NAME and a later generic
    # CMake rule consumes it. Resolve exact string values against real board directories.
    string_values = []
    for var, value in re.findall(r'set\(\s*([A-Za-z0-9_]+)\s+"([^"\n]+)"\s*\)', block):
        if any(key in var.upper() for key in ("BOARD", "TYPE", "NAME", "DIR")):
            string_values.append(value.strip())
    all_dirs = [p for p in boards_root.rglob("*") if p.is_dir()]
    for value in string_values:
        norm = value.strip("/\\")
        tests = [boards_root / norm, main / norm]
        for t in tests:
            if t.is_dir():
                d = candidate_from_path(t)
                if d:
                    found.append(d.resolve())
                    print(f"[board] CMake variable value {value!r} ->", d)
        for d0 in all_dirs:
            rel = d0.relative_to(boards_root).as_posix()
            if d0.name == norm or rel == norm or rel.endswith("/" + norm):
                d = candidate_from_path(d0)
                if d:
                    found.append(d.resolve())
                    print(f"[board] directory matches CMake value {value!r} ->", d)

    # Stable unique order.
    unique: list[Path] = []
    seen = set()
    for d in found:
        key = str(d)
        if key not in seen:
            unique.append(d)
            seen.add(key)
    return unique


def dirs_from_config_json() -> list[Path]:
    """Fallback to board metadata. This is deterministic and mirrors release build metadata."""
    exact: list[Path] = []
    product_like: list[Path] = []
    for cfg in boards_root.rglob("config.json"):
        try:
            raw = cfg.read_text(encoding="utf-8", errors="ignore")
            data = json.loads(raw)
        except Exception:
            continue
        lower_raw = raw.lower()
        if f"config_{BOARD_CONFIG.lower()}=y" in lower_raw or BOARD_CONFIG.lower() in lower_raw:
            exact.append(cfg.parent.resolve())
            continue

        manufacturer = str(data.get("manufacturer", "")).lower()
        type_name = str(data.get("type", "")).lower()
        build_names = " ".join(
            str(b.get("name", "")) for b in data.get("builds", []) if isinstance(b, dict)
        ).lower()
        identity = " ".join([manufacturer, type_name, build_names, cfg.parent.as_posix().lower()])
        # Vendor-specific fallback: non-4G SpotPear 3.5 camera board.
        looks_spotpear = "spotpear" in identity or "spotpear" in lower_raw
        looks_35 = any(x in identity for x in ("3.5", "3_5", "3-5", "35"))
        looks_cam = "cam" in identity or "camera" in identity or "gc0308" in lower_raw
        is_4g = "ml307" in identity or "4g" in identity
        if looks_spotpear and looks_35 and looks_cam and not is_4g:
            product_like.append(cfg.parent.resolve())

    result = exact if exact else product_like
    # Unique
    return list(dict.fromkeys(result))


def dirs_from_vendor_fingerprint() -> list[Path]:
    """Last-resort vendor-only scan; never score unrelated boards."""
    candidates = []
    for d in [p for p in boards_root.rglob("*") if p.is_dir()]:
        rel = d.relative_to(boards_root).as_posix().lower()
        files = [p for p in d.iterdir() if p.is_file() and p.suffix.lower() in SOURCE_SUFFIXES]
        if not files:
            continue
        blob = "\n".join(p.read_text(encoding="utf-8", errors="ignore") for p in files).lower()
        identity = rel + "\n" + blob
        # Require a SpotPear identity, then MAX35-specific hardware fingerprints.
        if "spotpear" not in identity:
            continue
        score = 0
        for kw, pts in (
            ("3.5", 20), ("max35", 20), ("gc0308", 10), ("gt911", 8),
            ("st7796", 8), ("es8311", 6), ("camera", 3),
        ):
            if kw in identity:
                score += pts
        if "ml307" in identity or "4g" in rel:
            score -= 25
        if score >= 20:
            candidates.append((score, d.resolve()))
    candidates.sort(key=lambda x: (-x[0], len(str(x[1]))))
    if not candidates:
        return []
    top = candidates[0][0]
    return [d for score, d in candidates if score == top]


def resolve_board_dirs(cmake_text: str) -> list[Path]:
    forced = os.environ.get("MAX35_BOARD_DIR", "").strip()
    if forced:
        p = Path(forced)
        if not p.is_absolute():
            p = boards_root / p
        if not p.is_dir():
            raise SystemExit(f"MAX35_BOARD_DIR is not a directory: {p}")
        print("[board] forced MAX35_BOARD_DIR ->", p)
        return [p.resolve()]

    block = extract_exact_board_block(cmake_text)

    for method, candidates in (
        ("exact CMake block", dirs_from_cmake_block(block)),
        ("board config.json", dirs_from_config_json()),
        ("SpotPear hardware fingerprint fallback", dirs_from_vendor_fingerprint()),
    ):
        # Remove common/shared and keep only real directories.
        cleaned = []
        for d in candidates:
            if not d.is_dir() or not is_under(d, boards_root):
                continue
            rel_parts = d.relative_to(boards_root).parts
            if rel_parts and rel_parts[0].lower() == "common":
                continue
            if d not in cleaned:
                cleaned.append(d)
        if len(cleaned) == 1:
            print(f"[board] resolved by {method}:", cleaned[0])
            return cleaned
        if len(cleaned) > 1:
            # Prefer the only candidate whose own files touch the display stack.
            display_dirs = []
            for d in cleaned:
                blob = "\n".join(
                    p.read_text(encoding="utf-8", errors="ignore")
                    for p in d.rglob("*")
                    if p.is_file() and p.suffix.lower() in {".cc", ".cpp", ".h", ".hpp"}
                )
                if "SpiLcdDisplay" in blob or "LcdDisplay" in blob:
                    display_dirs.append(d)
            if len(display_dirs) == 1:
                print(f"[board] resolved by {method} + display ownership:", display_dirs[0])
                return display_dirs
            print(f"[board] {method} candidates:")
            for d in cleaned:
                print("   -", d)

    raise SystemExit(
        "Could not resolve the SpotPear MAX35 board source directory from the real vendor tree. "
        "The exact CMake block was printed above; set repository variable MAX35_BOARD_DIR only "
        "if the vendor uses an unusual shared-board layout."
    )


# ---------------------------------------------------------------------------
# 1. Copy only our product display layer.
# ---------------------------------------------------------------------------
overlay_src = repo / "overlay/main/display/stellar_max35"
overlay_dst = main / "display/stellar_max35"

if not overlay_src.is_dir():
    raise SystemExit(f"overlay missing: {overlay_src}")

if overlay_dst.exists():
    shutil.rmtree(overlay_dst)
shutil.copytree(overlay_src, overlay_dst)
print("[copy]", overlay_dst)

# ---------------------------------------------------------------------------
# 2. Add product sources to main/CMakeLists.txt.
# ---------------------------------------------------------------------------
cmake = cmake_path.read_text(encoding="utf-8", errors="ignore")

sources = [
    "display/stellar_max35/stellar_max35_display.cc",
    "display/stellar_max35/ui_home.cc",
    "display/stellar_max35/ui_chat.cc",
    "display/stellar_max35/ui_camera.cc",
    "display/stellar_max35/ui_character.c",
    "display/stellar_max35/camera_gate.cc",
    "display/stellar_max35/stellar_todo.cc",
    "display/stellar_max35/product_tools.cc",
]

missing = [s for s in sources if f'"{s}"' not in cmake]
if missing:
    anchor = '"display/lcd_display.cc"'
    if anchor in cmake:
        addition = "\n".join(f'            "{s}"' for s in missing)
        cmake = cmake.replace(anchor, anchor + "\n" + addition, 1)
    else:
        # Older forks can assemble SOURCES and register later. Insert a list(APPEND)
        # before idf_component_register instead of guessing board-specific layout.
        register_pos = cmake.find("idf_component_register(")
        if register_pos < 0 or not re.search(r"\bset\s*\(\s*SOURCES\b", cmake, re.I):
            raise SystemExit("main/CMakeLists.txt has no lcd_display source anchor or SOURCES list")
        addition = "\n# STELLAR_MAX35_SOURCES\nlist(APPEND SOURCES\n"
        addition += "".join(f'    "{s}"\n' for s in missing)
        addition += ")\n\n"
        cmake = cmake[:register_pos] + addition + cmake[register_pos:]
    cmake_path.write_text(cmake, encoding="utf-8")
    print("[patch] main/CMakeLists.txt -> product UI sources")

# Resolve the real SpotPear board without assuming Waveshare's BOARD_DIR syntax.
board_dirs = resolve_board_dirs(cmake)
board_files = []
for board_dir in board_dirs:
    board_files.extend(
        p for p in board_dir.rglob("*")
        if p.is_file() and p.suffix.lower() in {".h", ".hpp", ".cc", ".cpp"}
    )
board_files = sorted(set(board_files))
if not board_files:
    raise SystemExit(f"MAX35 board source files missing under: {board_dirs}")

print("[board] files considered for display integration:")
for p in board_files:
    print("   -", p.relative_to(main))

display_include = '#include "display/stellar_max35/stellar_max35_display.h"'
tools_include = '#include "display/stellar_max35/product_tools.h"'

# ---------------------------------------------------------------------------
# 3. Attach StellarMax35Display while preserving SpotPear hardware code.
# ---------------------------------------------------------------------------
patched_display = False
registered_tools = False

for f in board_files:
    text = f.read_text(encoding="utf-8", errors="ignore")
    original = text

    relevant = (
        "SpiLcdDisplay" in text
        or "LcdDisplay" in text
        or "InitializeTools" in text
        or "StellarMax35Display" in text
    )
    if not relevant:
        continue

    if ("SpiLcdDisplay" in text or "LcdDisplay" in text or "StellarMax35Display" in text):
        if display_include not in text:
            include_anchor = '#include "display/lcd_display.h"'
            if include_anchor in text:
                text = text.replace(include_anchor, include_anchor + "\n" + display_include, 1)
            else:
                # Keep pragma/include guards legal: add after #pragma once when present.
                pragma = re.search(r"(?m)^#pragma once\s*$", text)
                if pragma:
                    eol = text.find("\n", pragma.end())
                    at = len(text) if eol < 0 else eol + 1
                    text = text[:at] + display_include + "\n" + text[at:]
                else:
                    text = display_include + "\n" + text

    if "InitializeTools" in text and tools_include not in text:
        text = tools_include + "\n" + text

    # Case A: board directly constructs SpiLcdDisplay.
    text, n_direct = re.subn(
        r"new\s+SpiLcdDisplay\s*\(",
        "new StellarMax35Display(",
        text,
        count=1,
    )
    if n_direct:
        patched_display = True
        print("[patch] direct SpiLcdDisplay -> StellarMax35Display:", f.relative_to(main))

    # Case B: board has a custom display subclass. Keep it, replace only its base.
    classes = re.findall(
        r"class\s+([A-Za-z_][A-Za-z0-9_]*)\s*:\s*public\s+SpiLcdDisplay",
        text,
    )
    for cls in classes:
        text = re.sub(
            rf"class\s+{re.escape(cls)}\s*:\s*public\s+SpiLcdDisplay",
            f"class {cls} : public StellarMax35Display",
            text,
            count=1,
        )
        text = text.replace(
            "using SpiLcdDisplay::SpiLcdDisplay;",
            "using StellarMax35Display::StellarMax35Display;",
        )
        # Explicit base constructor in an initializer list.
        text = re.sub(
            r":\s*SpiLcdDisplay\s*\(",
            ": StellarMax35Display(",
            text,
            count=1,
        )
        patched_display = True
        print(f"[patch] preserve {cls}, base -> StellarMax35Display:", f.relative_to(main))

    if "stellar_max35::RegisterProductTools();" in text:
        registered_tools = True
    elif "InitializeTools" in text:
        m = re.search(r"void\s+InitializeTools\s*\([^)]*\)\s*\{", text)
        if m:
            close = function_close(text, m.start())
            indent_match = re.search(r"(?m)^(\s*)void\s+InitializeTools", text[:m.end()])
            body_indent = (indent_match.group(1) if indent_match else "    ") + "    "
            text = (
                text[:close]
                + f"{body_indent}stellar_max35::RegisterProductTools();\n"
                + text[close:]
            )
            registered_tools = True
            print("[patch] RegisterProductTools -> InitializeTools:", f.relative_to(main))

    if text != original:
        f.write_text(text, encoding="utf-8")

if not patched_display:
    snippets = []
    for f in board_files:
        t = f.read_text(encoding="utf-8", errors="ignore")
        if "Display" in t or "display_" in t:
            snippets.append(str(f.relative_to(main)))
    raise SystemExit(
        "MAX35 board was resolved, but its source does not use the expected SpiLcdDisplay "
        "construction/subclass. Display-related files: " + ", ".join(snippets[:20])
    )

# ---------------------------------------------------------------------------
# 4. Camera: preserve Xiaozhi native Capture()/Explain(), add touch shutter gate.
# ---------------------------------------------------------------------------
mcp = main / "mcp_server.cc"
if not mcp.exists():
    raise SystemExit("main/mcp_server.cc missing")

text = mcp.read_text(encoding="utf-8", errors="ignore")

gate_include = '#include "display/stellar_max35/camera_gate.h"'
if gate_include not in text:
    first_include = text.find("#include")
    eol = text.find("\n", first_include)
    if first_include < 0 or eol < 0:
        raise SystemExit("mcp_server.cc include block not found")
    text = text[:eol + 1] + gate_include + "\n" + text[eol + 1:]

if not registered_tools and tools_include not in text:
    first_include = text.find("#include")
    eol = text.find("\n", first_include)
    text = text[:eol + 1] + tools_include + "\n" + text[eol + 1:]

if "stellar_max35::WaitForCameraConsent" not in text:
    # Preferred vendor/xiaozhi form: if (!camera->Capture()) { ... }
    capture = re.search(
        r"if\s*\(\s*!\s*camera->Capture\s*\(\s*\)\s*\)\s*\{",
        text,
    )
    if capture:
        insert_at = capture.start()
    else:
        # Fallback: any standalone/assigned Capture call. Insert before the containing line.
        generic = re.search(r"camera->Capture\s*\(\s*\)", text)
        if not generic:
            raise SystemExit("Native camera->Capture() anchor not found in mcp_server.cc")
        insert_at = text.rfind("\n", 0, generic.start()) + 1

    line_start = text.rfind("\n", 0, insert_at) + 1
    indent = re.match(r"[ \t]*", text[line_start:insert_at]).group(0)
    gate = (
        f'{indent}if (!stellar_max35::WaitForCameraConsent('
        'properties["question"].value<std::string>(), 30000)) {\n'
        f'{indent}    throw std::runtime_error("Camera capture cancelled or timed out");\n'
        f'{indent}}}\n'
    )
    text = text[:insert_at] + gate + text[insert_at:]
    print("[patch] touch shutter gate -> native camera Capture()")

if not registered_tools and "stellar_max35::RegisterProductTools();" not in text:
    # Current Xiaozhi explicitly reserves board InitializeTools for custom tools. Older
    # vendor forks may still have the restore marker in AddCommonTools.
    restore = "// Restore the original tools list"
    if restore in text:
        text = text.replace(
            restore,
            "stellar_max35::RegisterProductTools();\n\n    " + restore,
            1,
        )
        print("[patch] RegisterProductTools -> MCP fallback")
    else:
        raise SystemExit(
            "No board InitializeTools() and no safe MCP registration anchor was found"
        )

mcp.write_text(text, encoding="utf-8")

print("[done] STELLAR MAX35 product patch applied")
print("[done] vendor hardware code retained in:")
for d in board_dirs:
    print("   -", d)
