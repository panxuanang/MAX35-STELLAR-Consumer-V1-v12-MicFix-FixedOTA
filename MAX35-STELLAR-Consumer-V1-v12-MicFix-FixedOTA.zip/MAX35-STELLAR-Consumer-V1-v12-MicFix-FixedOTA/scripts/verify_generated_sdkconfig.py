#!/usr/bin/env python3
from pathlib import Path
import re
import sys

if len(sys.argv) != 2:
    raise SystemExit("usage: verify_generated_sdkconfig.py <xiaozhi-source-root>")
root = Path(sys.argv[1]).resolve()
sdk = root / "sdkconfig"
if not sdk.exists():
    raise SystemExit("idf.py did not generate sdkconfig")
text = sdk.read_text(encoding="utf-8", errors="ignore")

FIXED_OTA_URL = "http://124.221.112.55:8002/xiaozhi/ota/"


def require(line: str, why: str):
    if line not in text:
        raise SystemExit(f"generated sdkconfig missing {line} ({why})")
    print("[OK]", line)


def require_disabled(symbol: str, why: str):
    enabled = f"CONFIG_{symbol}=y"
    if enabled in text:
        raise SystemExit(f"generated sdkconfig unexpectedly enables {enabled} ({why})")
    disabled = f"# CONFIG_{symbol} is not set"
    if disabled in text:
        print("[OK]", disabled)
    else:
        # Some IDF/Kconfig combinations omit invisible symbols entirely. The hard
        # requirement is that the feature must not be enabled.
        print(f"[OK] CONFIG_{symbol} is not enabled")


require("CONFIG_BOARD_TYPE_SPOTPEAR_ESP32_S3_3_5_LCD=y", "wrong board would compile")
require(
    f'CONFIG_OTA_URL="{FIXED_OTA_URL}"',
    "firmware must always discover the user's Xiaozhi backend through the fixed OTA URL",
)
require_disabled(
    "USE_DEVICE_AEC",
    "single-MIC diagnostic build must not consume a possibly mis-routed playback reference",
)
require_disabled(
    "USE_SERVER_AEC",
    "keep the microphone test path deterministic and independent of server AEC support",
)

board_dir = root / "main/boards" / (root / ".stellar_max35_board_type").read_text().strip()
blob = "\n".join(
    p.read_text(encoding="utf-8", errors="ignore")
    for p in board_dir.rglob("*")
    if p.is_file() and p.suffix.lower() in {".c", ".cc", ".cpp", ".h", ".hpp"}
)
if any(x in blob for x in (
    "esp_video_init_dvp_config_t",
    "esp_video_init_sccb_config_t",
    "esp_cam_ctlr_dvp_pin_config_t",
)):
    require("CONFIG_ESP_VIDEO_ENABLE_DVP_VIDEO_DEVICE=y", "MAX35 board source directly uses esp_video DVP types")
    # CAM_CTRL_DVP_ENABLE exists in the esp_cam_sensor stack used by this board.
    if "CONFIG_CAM_CTRL_DVP_ENABLE=y" in text:
        print("[OK] CONFIG_CAM_CTRL_DVP_ENABLE=y")
    else:
        print("[WARN] CONFIG_CAM_CTRL_DVP_ENABLE not visible in final sdkconfig; esp_video DVP is the hard compile gate")

ktext = "\n".join(
    p.read_text(encoding="utf-8", errors="ignore")
    for p in root.rglob("Kconfig*") if p.is_file()
)
if re.search(r"(?m)^\s*(?:menu)?config\s+CAMERA_GC0308\s*$", ktext):
    require("CONFIG_CAMERA_GC0308=y", "rear-camera SKU uses GC0308")

# This MAX35 rear-camera SKU must never boot with OV2640/OV5640 probing enabled.
# The SpotPear board code resets the device when camera detection fails.
foreign_enabled = []
for line in text.splitlines():
    if line.startswith("CONFIG_") and line.endswith("=y") and ("OV2640" in line or "OV5640" in line):
        foreign_enabled.append(line)
if foreign_enabled:
    raise SystemExit(
        "generated sdkconfig still enables a non-SKU camera; refusing to build:\n"
        + "\n".join(foreign_enabled)
    )
print("[OK] OV2640/OV5640 disabled; GC0308 is exclusive")

print("===== final defaults ordering =====")
for name in ("sdkconfig.defaults", "sdkconfig.defaults.esp32s3"):
    p = root / name
    if p.exists():
        print(f"--- {name} ---")
        for line in p.read_text(encoding="utf-8", errors="ignore").splitlines():
            up = line.upper()
            if any(x in up for x in (
                "SPOTPEAR", "GC0308", "DVP", "ESP_VIDEO", "WECHAT", "CAMERA",
                "USE_DEVICE_AEC", "USE_SERVER_AEC", "OTA_URL",
            )):
                print(line)

print("===== generated audio/OTA/camera sdkconfig =====")
for line in text.splitlines():
    up = line.upper()
    if any(x in up for x in (
        "SPOTPEAR", "GC0308", "DVP", "ESP_VIDEO", "WECHAT", "CAMERA",
        "USE_DEVICE_AEC", "USE_SERVER_AEC", "OTA_URL",
    )):
        print(line)
print("[done] generated sdkconfig verified: MAX35 + single MIC/no AEC + fixed OTA")
