#!/usr/bin/env python3
"""Lock Xiaozhi OTA/backend discovery to the user's server and ignore old NVS ota_url."""
from __future__ import annotations

from pathlib import Path
import re
import sys

FIXED_OTA_URL = "http://124.221.112.55:8002/xiaozhi/ota/"

if len(sys.argv) != 2:
    raise SystemExit("usage: fix_fixed_ota.py <xiaozhi-source-root>")

root = Path(sys.argv[1]).resolve()
ota = root / "main" / "ota.cc"
if not ota.exists():
    raise SystemExit(f"OTA source missing: {ota}")

text = ota.read_text(encoding="utf-8", errors="ignore")

sig = re.search(r"(?m)^std::string\s+Ota::GetCheckVersionUrl\s*\(\s*\)\s*\{", text)
if not sig:
    raise SystemExit("Ota::GetCheckVersionUrl() not found")

brace = text.find("{", sig.start())
depth = 0
end = None
for i in range(brace, len(text)):
    if text[i] == "{":
        depth += 1
    elif text[i] == "}":
        depth -= 1
        if depth == 0:
            end = i + 1
            break
if end is None:
    raise SystemExit("Ota::GetCheckVersionUrl() closing brace not found")

replacement = '''std::string Ota::GetCheckVersionUrl() {
    // STELLAR MAX35 FIXED OTA: do not allow an old NVS wifi/ota_url value to redirect this build.
    return CONFIG_OTA_URL;
}'''
text = text[:sig.start()] + replacement + text[end:]
ota.write_text(text, encoding="utf-8")
print(f"[ota] GetCheckVersionUrl locked to CONFIG_OTA_URL -> {FIXED_OTA_URL}")
print("[done] fixed OTA runtime patch applied")
