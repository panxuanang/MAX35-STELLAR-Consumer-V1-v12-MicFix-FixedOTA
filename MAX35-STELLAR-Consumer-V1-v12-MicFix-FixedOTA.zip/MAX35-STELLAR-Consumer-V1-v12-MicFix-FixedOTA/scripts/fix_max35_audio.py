#!/usr/bin/env python3
"""Apply a narrow MAX35 microphone stability patch to the downloaded SpotPear tree.

Scope:
- keep the known-good Wi-Fi/LCD/UI/speaker/camera path unchanged;
- disable the ES7210 playback-reference path for this build;
- force a single real microphone channel into AFE;
- use a moderate microphone gain;
- add once-per-second RMS/peak diagnostics so hardware input can be verified from UART.

The patch intentionally touches only the selected MAX35 board config and the shared
BoxAudioCodec used by that board in the vendor source downloaded by CI.
"""
from __future__ import annotations

from pathlib import Path
import re
import sys

if len(sys.argv) != 2:
    raise SystemExit("usage: fix_max35_audio.py <xiaozhi-source-root>")

root = Path(sys.argv[1]).resolve()
main = root / "main"
board_marker = root / ".stellar_max35_board_type"
if not main.is_dir() or not board_marker.exists():
    raise SystemExit(f"invalid or not-yet-configured Xiaozhi source root: {root}")

board_type = board_marker.read_text(encoding="utf-8").strip()
board_dir = main / "boards" / board_type
config_h = board_dir / "config.h"
codec_cc = main / "audio" / "codecs" / "box_audio_codec.cc"

if not config_h.exists():
    raise SystemExit(f"selected MAX35 config.h missing: {config_h}")
if not codec_cc.exists():
    raise SystemExit(f"BoxAudioCodec source missing: {codec_cc}")

# 1) Board-level contract: one microphone, no hardware playback reference.
config = config_h.read_text(encoding="utf-8", errors="ignore")
config_new, count = re.subn(
    r"(?m)^(\s*#define\s+AUDIO_INPUT_REFERENCE\s+)(?:true|false|1|0)(\s*(?://.*)?)$",
    r"\1false\2",
    config,
    count=1,
)
if count != 1:
    raise SystemExit(
        "Could not find exactly one AUDIO_INPUT_REFERENCE define in selected MAX35 config.h"
    )
if "STELLAR MAX35 MIC FIX" not in config_new:
    marker = (
        "\n// STELLAR MAX35 MIC FIX: use one physical microphone first; "
        "do not feed a possibly-misrouted ES7210 slot into AEC as playback reference.\n"
    )
    # Put the marker next to the audio definition without changing GPIOs.
    pos = config_new.find("#define AUDIO_INPUT_REFERENCE")
    if pos >= 0:
        line_start = config_new.rfind("\n", 0, pos) + 1
        config_new = config_new[:line_start] + marker + config_new[line_start:]
config_h.write_text(config_new, encoding="utf-8")
print(f"[audio] {config_h.relative_to(root)}: AUDIO_INPUT_REFERENCE=false")

# 2) BoxAudioCodec: make the single-mic path deterministic and observable.
text = codec_cc.read_text(encoding="utf-8", errors="ignore")

# Required includes for UART energy diagnostics.
for include in ("#include <esp_timer.h>", "#include <cmath>", "#include <cstdint>"):
    if include not in text:
        anchor = "#include <esp_codec_dev.h>"
        if anchor in text:
            text = text.replace(anchor, anchor + "\n" + include, 1)
        else:
            first_blank = text.find("\n\n")
            if first_blank < 0:
                text = include + "\n" + text
            else:
                text = text[:first_blank] + "\n" + include + text[first_blank:]

# Moderate gain: high enough for a quiet enclosure, below the aggressive clipping range.
text, gain_count = re.subn(
    r"(?m)^(\s*)input_gain_\s*=\s*[^;\n]+;[^\n]*$",
    r"\1input_gain_ = 30.0f; // STELLAR MAX35 MIC FIX",
    text,
    count=1,
)
if gain_count != 1:
    raise SystemExit("Could not patch BoxAudioCodec input_gain_")

# Power only MIC1 in the no-reference build. If a future build turns reference back on,
# preserve the vendor's four-input behavior rather than silently changing other boards.
if "STELLAR MAX35 MIC FIX: single physical mic" not in text:
    mic_sel_pattern = re.compile(r"(?m)^(\s*)es7210_cfg\.mic_selected\s*=\s*[^;\n]+;\s*$")
    m = mic_sel_pattern.search(text)
    if not m:
        raise SystemExit("Could not locate ES7210 mic_selected assignment")
    indent = m.group(1)
    mic_sel_replacement = (
        f"{indent}es7210_cfg.mic_selected = input_reference_\n"
        f"{indent}    ? (ES7210_SEL_MIC1 | ES7210_SEL_MIC2 | ES7210_SEL_MIC3 | ES7210_SEL_MIC4)\n"
        f"{indent}    : ES7210_SEL_MIC1; // STELLAR MAX35 MIC FIX: single physical mic\n"
    )
    text = text[:m.start()] + mic_sel_replacement + text[m.end():]


def function_close(src: str, signature_pos: int) -> int:
    brace = src.find("{", signature_pos)
    if brace < 0:
        raise SystemExit("function opening brace not found")
    depth = 0
    for i in range(brace, len(src)):
        if src[i] == "{":
            depth += 1
        elif src[i] == "}":
            depth -= 1
            if depth == 0:
                return i + 1
    raise SystemExit("function closing brace not found")

# Replace the vendor Read() body. Important behavior change: a codec read failure now returns
# zero samples instead of forwarding an invalid/empty frame to VAD/ASR.
sig = re.search(r"(?m)^int\s+BoxAudioCodec::Read\s*\(\s*int16_t\s*\*\s*dest\s*,\s*int\s+samples\s*\)\s*\{", text)
if not sig:
    raise SystemExit("Could not locate BoxAudioCodec::Read")
end = function_close(text, sig.start())
read_impl = r'''int BoxAudioCodec::Read(int16_t* dest, int samples) {
    if (!input_enabled_ || dest == nullptr || samples <= 0) {
        return 0;
    }

    esp_err_t ret = esp_codec_dev_read(input_dev_, (void*)dest, samples * sizeof(int16_t));
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "MAX35 microphone read failed: %s", esp_err_to_name(ret));
        return 0;
    }

    // STELLAR MAX35 MIC FIX: once-per-second raw-input diagnostics.
    // Quiet room should still show a small non-zero noise floor; speaking should raise
    // RMS/peak clearly. This lets UART distinguish software/AEC issues from no PCM input.
    static int64_t last_mic_diag_us = 0;
    const int64_t now_us = esp_timer_get_time();
    if (now_us - last_mic_diag_us >= 1000000) {
        int64_t sum_sq = 0;
        int32_t peak = 0;
        for (int i = 0; i < samples; ++i) {
            const int32_t v = dest[i];
            const int32_t a = v < 0 ? -v : v;
            if (a > peak) {
                peak = a;
            }
            sum_sq += static_cast<int64_t>(v) * static_cast<int64_t>(v);
        }
        const int32_t rms = static_cast<int32_t>(std::sqrt(
            static_cast<double>(sum_sq) / static_cast<double>(samples)));
        ESP_LOGI(TAG, "MAX35 MIC RMS=%ld peak=%ld gain=%.1f ref=%d",
                 static_cast<long>(rms), static_cast<long>(peak),
                 input_gain_, input_reference_ ? 1 : 0);
        last_mic_diag_us = now_us;
    }

    return samples;
}'''
text = text[:sig.start()] + read_impl + text[end:]

codec_cc.write_text(text, encoding="utf-8")
print(f"[audio] {codec_cc.relative_to(root)}: single MIC1, gain=30dB, RMS diagnostics enabled")
print("[audio] device-side AEC is expected to be disabled by configure_max35.py")
print("[done] MAX35 microphone patch applied")
