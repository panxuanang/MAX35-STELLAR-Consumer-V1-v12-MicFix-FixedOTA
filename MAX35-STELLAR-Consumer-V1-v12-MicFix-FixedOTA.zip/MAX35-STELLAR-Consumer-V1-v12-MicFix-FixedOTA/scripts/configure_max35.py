#!/usr/bin/env python3
"""Materialize the SpotPear MAX35 menuconfig choices deterministically.

The known-good Wi-Fi/display/camera baseline stays intact. This revision adds only
three final product-level constraints on top of V11: single-mic/no-device-AEC audio,
the user's fixed OTA/backend discovery URL, and the existing GC0308-only camera
selection. Vendor Kconfig files remain byte-for-byte untouched.
"""
from __future__ import annotations

from pathlib import Path
import json
import re
import shutil
import sys

if len(sys.argv) != 2:
    raise SystemExit("usage: configure_max35.py <xiaozhi-source-root>")

root = Path(sys.argv[1]).resolve()
main = root / "main"
boards = main / "boards"
kconfig = main / "Kconfig.projbuild"
if not boards.is_dir() or not kconfig.exists():
    raise SystemExit(f"invalid Xiaozhi source root: {root}")

BOARD_SYMBOL = "BOARD_TYPE_SPOTPEAR_ESP32_S3_3_5_LCD"
BOARD_KEY = f"CONFIG_{BOARD_SYMBOL}"
FIXED_OTA_URL = "http://124.221.112.55:8002/xiaozhi/ota/"


def read_text(p: Path) -> str:
    return p.read_text(encoding="utf-8", errors="ignore")


def all_kconfig_text() -> str:
    out: list[str] = []
    for p in root.rglob("Kconfig*"):
        if p.is_file():
            try:
                out.append(read_text(p))
            except OSError:
                pass
    return "\n".join(out)


KCONFIG_TEXT = all_kconfig_text()


def symbol_defined(symbol: str) -> bool:
    return re.search(
        rf"(?m)^\s*(?:menu)?config\s+{re.escape(symbol)}\s*$", KCONFIG_TEXT
    ) is not None


if not symbol_defined(BOARD_SYMBOL):
    raise SystemExit(f"SpotPear MAX35 Kconfig symbol not found: {BOARD_SYMBOL}")


def source_blob(d: Path) -> str:
    parts: list[str] = []
    for p in sorted(d.rglob("*")):
        if p.is_file() and p.suffix.lower() in {".c", ".cc", ".cpp", ".h", ".hpp"}:
            parts.append(read_text(p))
    return "\n".join(parts)


# CI from the real vendor package already confirmed this directory.
preferred = boards / "sp-esp32-s3-lcd-3.5" / "config.json"
if not preferred.exists():
    matches: list[Path] = []
    for cfg_path in boards.rglob("config.json"):
        try:
            data = json.loads(read_text(cfg_path))
        except Exception:
            continue
        identity = (cfg_path.as_posix() + " " + json.dumps(data, ensure_ascii=False)).lower()
        if ("spotpear" in identity or "sp-esp32-s3-lcd-3.5" in identity) and "3.5" in identity:
            matches.append(cfg_path)
    if len(matches) != 1:
        raise SystemExit("Could not uniquely locate SpotPear MAX35 config.json")
    preferred = matches[0]

cfg_path = preferred
cfg = json.loads(read_text(cfg_path))
board_dir = cfg_path.parent
board_type = board_dir.relative_to(boards).as_posix()
target = str(cfg.get("target", "esp32s3")).strip() or "esp32s3"
print(f"[vendor] board={board_type}")
print(f"[vendor] target={target}")
print(f"[vendor] config={cfg_path}")

builds = cfg.get("builds", [])
if not isinstance(builds, list):
    builds = []


def build_score(b: dict) -> int:
    text = json.dumps(b, ensure_ascii=False).lower()
    score = 0
    if "gc0308" in text:
        score += 120
    if "yuv422" in text:
        score += 25
    if any(x in text for x in ("bcamera", "rear", "back", "behind")):
        score += 30
    if "90" in text:
        score += 10
    if "ml307" in text or "4g" in text:
        score -= 200
    return score


valid_builds = [b for b in builds if isinstance(b, dict)]
if valid_builds:
    selected = max(enumerate(valid_builds), key=lambda ib: (build_score(ib[1]), -ib[0]))[1]
else:
    selected = {"name": board_type, "sdkconfig_append": []}

build_name = str(selected.get("name", board_type)).strip() or board_type
append = selected.get("sdkconfig_append", []) or []
if not isinstance(append, list):
    raise SystemExit("vendor sdkconfig_append is not a list")
append = [str(x).strip() for x in append if str(x).strip()]
print(f"[vendor] selected build={build_name}")
print("[vendor] sdkconfig_append entries:")
for line in append:
    print("   ", line)

blob = source_blob(board_dir)

# Product-owned choices. Only use symbols that actually exist in this vendor
# component tree, except the board choice which is already confirmed above.
forced: dict[str, str] = {BOARD_KEY: "y"}

for sym, value in (
    ("CONFIG_USE_WECHAT_MESSAGE_STYLE", "n"),
    ("CONFIG_USE_DEFAULT_MESSAGE_STYLE", "y"),
    ("CONFIG_LV_FONT_MONTSERRAT_48", "y"),
):
    raw = sym.removeprefix("CONFIG_")
    if symbol_defined(raw):
        forced[sym] = value

# MAX35 microphone stabilization: feed one real mic channel to AFE and keep
# device-side AEC disabled until a verified playback-reference slot mapping is used.
for sym, value in (
    ("CONFIG_USE_DEVICE_AEC", "n"),
    ("CONFIG_USE_SERVER_AEC", "n"),
):
    raw = sym.removeprefix("CONFIG_")
    if symbol_defined(raw):
        forced[sym] = value

# The user requested this firmware to always discover the backend through this
# OTA endpoint. Runtime NVS override is disabled separately in fix_fixed_ota.py.
if symbol_defined("OTA_URL"):
    forced["CONFIG_OTA_URL"] = f'"{FIXED_OTA_URL}"'

uses_dvp_types = any(tok in blob for tok in (
    "esp_video_init_dvp_config_t",
    "esp_video_init_sccb_config_t",
    "esp_cam_ctlr_dvp_pin_config_t",
))

if uses_dvp_types:
    for sym in ("ESP_VIDEO_ENABLE_DVP_VIDEO_DEVICE", "CAM_CTRL_DVP_ENABLE"):
        if symbol_defined(sym):
            forced[f"CONFIG_{sym}"] = "y"

# The physical rear-camera SKU on this product is GC0308.  Do not let the
# generic SpotPear preset probe OV2640/OV5640 first: this board treats a failed
# camera probe as a hardware fault and reboots.  Make the camera selection
# exclusive and deterministic.
for sym in (
    "CAMERA_GC0308",
    "CAMERA_GC0308_AUTO_DETECT_DVP_INTERFACE_SENSOR",
    "CAMERA_GC0308_DVP_YUV422_YUYV_640X480_16FPS",
    "CAMERA_GC0308_DVP_DEFAULT_FMT_YUV422_YUYV_640X480_16FPS",
    "CAMERA_GC0308_DVP_YUV422_640X480_16FPS",
    "CAMERA_GC0308_DVP_DEFAULT_FMT_YUV422_640X480_16FPS",
    "GC0308_SUPPORT",
):
    if symbol_defined(sym):
        forced[f"CONFIG_{sym}"] = "y"

# Explicitly disable every Kconfig symbol belonging to OV2640 or OV5640 in the
# exact vendor component tree. This catches the sensor enable, auto-detect and
# format-choice symbols without assuming a particular esp-video version.
foreign_camera_symbols = sorted(set(re.findall(
    r"(?m)^\s*(?:menu)?config\s+([A-Za-z0-9_]*(?:OV2640|OV5640)[A-Za-z0-9_]*)\s*$",
    KCONFIG_TEXT,
)))
for sym in foreign_camera_symbols:
    forced[f"CONFIG_{sym}"] = "n"
if foreign_camera_symbols:
    print("[camera] disabled non-SKU camera symbols:")
    for sym in foreign_camera_symbols:
        print(f"    CONFIG_{sym}=n")

# Detect a unique rear-camera 90-degree boolean if the vendor fork exposes one.
blocks: list[str] = []
pat = re.compile(
    r"(?ms)^\s*(?:menu)?config\s+([A-Za-z0-9_]+)\s*\n(.*?)(?=^\s*(?:menu)?config\s+[A-Za-z0-9_]+\s*$|^\s*(?:choice|endchoice|menu|endmenu)\b|\Z)"
)
for m in pat.finditer(KCONFIG_TEXT):
    sym, body = m.group(1), m.group(2)
    low = (sym + "\n" + body).lower()
    if "bool" not in low:
        continue
    cameraish = any(x in low for x in (
        "camera", "rear", "back", "behind", "rotation", "rotate", "摄像", "后摄", "后置"
    ))
    ninety = any(x in low for x in ("90°", "90 degree", "90-degree", " 90 ", '"90"'))
    frontish = any(x in low for x in ("270°", "270 degree", "front camera", "前摄", "前置"))
    if cameraish and ninety and not frontish:
        blocks.append(sym)
if len(blocks) == 1:
    forced[f"CONFIG_{blocks[0]}"] = "y"
    print(f"[vendor] rear-camera 90-degree symbol detected: CONFIG_{blocks[0]}=y")
elif blocks:
    print("[vendor] rear-camera 90-degree candidates left vendor-owned:", ", ".join(blocks))


def key_of(line: str) -> str | None:
    s = line.strip()
    m = re.match(r"(CONFIG_[A-Za-z0-9_]+)=", s)
    if m:
        return m.group(1)
    m = re.match(r"#\s*(CONFIG_[A-Za-z0-9_]+)\s+is not set", s)
    if m:
        return m.group(1)
    return None


def clean_conflicts(lines: list[str], override_keys: set[str], *, remove_all_boards: bool) -> list[str]:
    out: list[str] = []
    for line in lines:
        key = key_of(line)
        if key is None:
            out.append(line)
            continue
        if remove_all_boards and key.startswith("CONFIG_BOARD_TYPE_"):
            continue
        if key in override_keys:
            continue
        # Physical SKU is GC0308. Never carry conflicting OV2640/OV5640
        # selections from generic vendor defaults or sdkconfig_append.
        if "OV2640" in key or "OV5640" in key:
            continue
        out.append(line)
    return out

# Preserve vendor generic defaults, only remove choices that would conflict with
# the exact MAX35 SKU. This file loads first.
generic_path = root / "sdkconfig.defaults"
generic_lines = read_text(generic_path).splitlines() if generic_path.exists() else []
if generic_path.exists() and not (root / "sdkconfig.defaults.vendor-backup").exists():
    shutil.copy2(generic_path, root / "sdkconfig.defaults.vendor-backup")
generic_clean = clean_conflicts(generic_lines, set(forced), remove_all_boards=True)
generic_path.write_text("\n".join(generic_clean).rstrip() + "\n", encoding="utf-8")

# IMPORTANT: ESP-IDF loads sdkconfig.defaults.<target> AFTER sdkconfig.defaults.
# Put our final board/camera overrides here so a later target-specific default
# cannot turn DVP back off.
target_defaults = root / f"sdkconfig.defaults.{target}"
target_lines = read_text(target_defaults).splitlines() if target_defaults.exists() else []
if target_defaults.exists() and not (root / f"sdkconfig.defaults.{target}.vendor-backup").exists():
    shutil.copy2(target_defaults, root / f"sdkconfig.defaults.{target}.vendor-backup")

# Vendor build append belongs to the same final layer as the selected variant.
append_map: dict[str, str] = {}
for line in append:
    k = key_of(line)
    if k:
        append_map[k] = line

final_map: dict[str, str] = dict(append_map)
for key, val in forced.items():
    final_map[key] = f"{key}={val}" if val != "n" else f"# {key} is not set"

override_keys = set(final_map)
target_clean = clean_conflicts(target_lines, override_keys, remove_all_boards=True)
target_out = target_clean + [
    "",
    "# --- STELLAR MAX35 final overrides: UI + GC0308 + single mic + fixed OTA ---",
]
target_out += list(final_map.values())
target_defaults.write_text("\n".join(target_out).rstrip() + "\n", encoding="utf-8")

# V9: Do not patch main/Kconfig.projbuild. Hardware Kconfig remains vendor-owned.
# Final selections live in sdkconfig.defaults.<target> and are verified after
# `idf.py reconfigure` against the generated sdkconfig.
print("[kconfig] vendor Kconfig left untouched (V9)")

(root / ".stellar_max35_board_type").write_text(board_type + "\n", encoding="utf-8")
(root / ".stellar_max35_build_name").write_text(build_name + "\n", encoding="utf-8")
(root / ".stellar_max35_config_path").write_text(str(cfg_path.relative_to(root)) + "\n", encoding="utf-8")
(root / ".stellar_max35_target").write_text(target + "\n", encoding="utf-8")

print("[ok] SpotPear generic defaults preserved")
print(f"[ok] final MAX35 overrides written to {target_defaults.name}")
print("[final overrides]")
for line in final_map.values():
    print("   ", line)
